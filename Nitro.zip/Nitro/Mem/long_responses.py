import random
import colorama

R_EATING = "I dont eat"
R_ADVICE = "good question I sadly dont know"


def unknown():
    response = ["Could you please re-phrase that? ",
                "...",
                "Sounds about right.",
                "What does that mean?"][
        random.randrange(4)]
    return response
