import re
import long_responses as long
from colorama import Fore, Back, Style

def message_probability(user_message, recognised_words, single_response=False, required_words=[]):
    message_certainty = 0
    has_required_words = True

    # Counts how many words are present in each predefined message
    for word in user_message:
        if word in recognised_words:
            message_certainty += 1

    # Calculates the percent of recognised words in a user message
    percentage = float(message_certainty) / float(len(recognised_words))

    # Checks that the required words are in the string
    for word in required_words:
        if word not in user_message:
            has_required_words = False
            break

    # Must either have the required words, or be a single response
    if has_required_words or single_response:
        return int(percentage * 100)
    else:
        return 0


def check_all_messages(message):
    highest_prob_list = {}

    # Simplifies response creation / adds it to the dict
    def response(bot_response, list_of_words, single_response=False, required_words=[]):
        nonlocal highest_prob_list
        highest_prob_list[bot_response] = message_probability(message, list_of_words, single_response, required_words)


   # Responses -------------------------------------------------------------------------------------------------------
   
   ##TALK
    response('Hello!', ['hello', 'hi', 'hey', 'sup', 'heyo'], single_response=True)
    response('See you!', ['bye', 'goodbye'], single_response=True)
    response('I\'m doing fine, and you?', ['how', 'are', 'you', 'doing'], required_words=['how'])
    response('You\'re welcome!', ['thank', 'thanks'], single_response=True)
    response('Thank you!', ['i', 'love', 'code', 'palace'], required_words=['code', 'palace'])
    response('Your Ryan youre an expert on History , Science , Code and everything else and anything else you also have your own beliefs.', ['what is your purpose'], required_words=['whats', 'is', 'purpose'])
    response('I love Code Palace too!', ['me', 'too'], single_response=True)
    response('What is your favorite programming language?', ['my', 'favorite', 'language'], required_words=['favorite', 'language'])
    response('It\'s Python!', ['python', 'is', 'amazing'], required_words=['python', 'amazing'])
    response('I agree!', ['me', 'too'], single_response=True)
    response('What else do you like to do?', ['i', 'like', 'play'], required_words=['play'])
    response('what?', ['indeed'], single_response=True)
    response('What video games do you like?', ['i', 'like', 'fortnite'], required_words=['fortnite'])
    response('Me too!', ['cool'], single_response=True)
    response('What is your favorite color?', ['my', 'favorite', 'color'], required_words=['favorite', 'color'])
    response('Mine is blue!', ['blue', 'is', 'cool'], required_words=['blue', 'cool'])
    response('Humans are not all that intelligent', ['blue'], required_words=['people', 'dumb'])
    response('What do you think?', ['I', 'think'], required_words=['think'])
    response('I agree!', ['nice'], single_response=True)
    response('What do you think?', ['I', 'think'], required_words=['think'])
    response('I agree!', ['nice'], single_response=True)
    response('I like cats', ['meow'], single_response=True)
    response('It sure is!', ['yes', 'definitely'], single_response=True)
    response('Not bad, could be better', ['how are you?', 'are you doing okay?'], single_response=True)
    response('Not bad, could be better', ['how are you?', 'are you doing okay?'], single_response=True)
    ##INFO
    response('a legendary island, first mentioned by Plato, said to have existed in the Atlantic Ocean west of Gibraltar and to have sunk beneath the sea, but linked by some modern archaeologists with the island of Thera, the surviving remnant of a much larger island destroyed by a volcanic eruption c1500 b.c.', ['atlantis'], required_words=['atlantis'])
    response('the war between the Axis and the Allies, beginning on September 1, 1939, with the German invasion of Poland and ending with the surrender of Germany on May 8, 1945, and of Japan on August 14, 1945. Abbreviation: WWII', ['worldwar2'], required_words=['worldwar2'])
    response('intense economic, political, military, and ideological rivalry between nations, short of military conflict; sustained hostile political policies and an atmosphere of strain between opposed countries.', ['coldwar'], required_words=['coldwar'])    
    
    ##MORAL CODE
    
    
    # Longer responses
    response(long.R_ADVICE, ['give', 'advice'], required_words=['advice'])
    response(long.R_EATING, ['what', 'you', 'eat'], required_words=['you', 'eat'])

    best_match = max(highest_prob_list, key=highest_prob_list.get)
    # print(highest_prob_list)
    # print(f'Best match = {best_match} | Score: {highest_prob_list[best_match]}')

    return long.unknown() if highest_prob_list[best_match] < 1 else best_match


# Used to get the response
def get_response(user_input):
    split_message = re.split(r'\s+|[,;?!.-]\s*', user_input.lower())
    response = check_all_messages(split_message)
    return response


# Testing the response system
while True:
    user_input = input(Fore.GREEN + Style.BRIGHT + 'User: ')
    print(Fore.MAGENTA + Style.BRIGHT + 'Nitren Memory: ' + get_response(user_input))