#Imports
import os
import time
from dotenv import load_dotenv
from colorama import Fore, Back, Style

#Terminal Print
print (Fore.MAGENTA + Style.BRIGHT + "███╗░░██╗██╗████████╗██████╗░░█████╗░░██████╗░█████╗░██╗░░░░░██╗░░░██╗████████╗██╗░█████╗░███╗░░██╗░██████╗")
print (Fore.BLUE + Style.BRIGHT + "████╗░██║██║╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔══██╗██║░░░░░██║░░░██║╚══██╔══╝██║██╔══██╗████╗░██║██╔════╝")
print (Fore.BLUE + Style.BRIGHT + "██╔██╗██║██║░░░██║░░░██████╔╝██║░░██║╚█████╗░██║░░██║██║░░░░░██║░░░██║░░░██║░░░██║██║░░██║██╔██╗██║╚█████╗░")
print (Fore.MAGENTA + Style.BRIGHT + "██║╚████║██║░░░██║░░░██╔══██╗██║░░██║░╚═══██╗██║░░██║██║░░░░░██║░░░██║░░░██║░░░██║██║░░██║██║╚████║░╚═══██╗")
print (Fore.MAGENTA + Style.BRIGHT + "██║░╚███║██║░░░██║░░░██║░░██║╚█████╔╝██████╔╝╚█████╔╝███████╗╚██████╔╝░░░██║░░░██║╚█████╔╝██║░╚███║██████╔╝")
print (Fore.BLUE + Style.BRIGHT + "╚═╝░░╚══╝╚═╝░░░╚═╝░░░╚═╝░░╚═╝░╚════╝░╚═════╝░░╚════╝░╚══════╝░╚═════╝░░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝╚═════╝░")
print (Fore.MAGENTA+ Style.BRIGHT + "======================================================")
print (Fore.MAGENTA + Style.BRIGHT + "Thanks for using NitroSolutions AI API Interface...")
print (Fore.MAGENTA + Style.BRIGHT + "Please select one of the following options: (1/A: ConnectionBot) or (2/B: AIMemory)")
print (Fore.MAGENTA + Style.BRIGHT + "!STARTING BOT Nitren!...")
print (Fore.MAGENTA + Style.BRIGHT + "======================================================")

#Obtains user Input
choice = input()

#Gets Key then on key press it takes you to specified file
if choice == '1':
    filename = "main.py"
elif choice == '2':
    filename = "BotMem.py"
    pathname = "Mem"

    os.chdir(pathname)


#Starts the program
os.system("python " + filename)